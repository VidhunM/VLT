# Vulture Studio

A modern React application built with Vite for a creative digital studio.

## Project Structure

```
vulture-studio/
├─ public/
│  └─ robots.txt
├─ src/
│  ├─ assets/              # images, models, fonts
│  ├─ components/
│  │  ├─ Header.jsx
│  │  ├─ HeroThree.jsx
│  │  └─ ProjectCard.jsx
│  ├─ pages/
│  │  ├─ Home.jsx
│  │  └─ Work.jsx
│  ├─ styles/
│  │  └─ main.css
│  ├─ App.jsx
│  └─ main.jsx
├─ index.html
├─ package.json
├─ vite.config.js
└─ README.md
```

## Features

- **Modern React Setup**: Built with React 18 and Vite for fast development
- **Routing**: React Router for navigation between pages
- **Responsive Design**: Mobile-first approach with modern CSS
- **Component Architecture**: Reusable components for maintainability
- **Modern Styling**: Clean, professional design with CSS Grid and Flexbox

## Getting Started

### Prerequisites

- Node.js (version 16 or higher)
- npm or yarn

### Installation

1. Navigate to the project directory:
   ```bash
   cd vulture-studio
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and visit `http://localhost:3000`

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Pages

- **Home**: Landing page with hero section, about, and services
- **Work**: Portfolio showcase with project cards

## Components

- **Header**: Navigation component with logo and menu
- **HeroThree**: Hero section with call-to-action buttons
- **ProjectCard**: Reusable card component for displaying projects

## Styling

The project uses a single CSS file (`main.css`) with:
- CSS Grid and Flexbox for layouts
- Responsive design with mobile-first approach
- Modern color scheme and typography
- Smooth transitions and hover effects

## Technologies Used

- React 18
- React Router DOM
- Vite
- CSS3
- ESLint

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test your changes
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).
#   V L T  
 