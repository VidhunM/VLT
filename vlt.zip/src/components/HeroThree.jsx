import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { navigateWithCircle } from '../utils/navigation'

const HeroThree = () => {
  const [selectedProject, setSelectedProject] = useState(0)
  const [previousProject, setPreviousProject] = useState(null)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const transitionTimeoutRef = useRef(null)
  const navigate = useNavigate()
  
  const handleNavigationClick = (event, path) => {
    navigateWithCircle(event, path, () => {
      navigate(path)
    })
  }

  const projects = [
    {
      name: 'drone-technology ',
      bgImage: 'https://images.pexels.com/photos/2050718/pexels-photo-2050718.jpeg'
    },
    {
      name: 'artificial-intelligence',
      bgImage: 'https://images.pexels.com/photos/8721318/pexels-photo-8721318.jpeg'
    },
    {
      name: 'iot-development',
      bgImage: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg'
    },
    {
      name: 'application-development',
      bgImage: 'https://images.pexels.com/photos/5473889/pexels-photo-5473889.jpeg'
    }
  ]

  const projectCount = projects.length

  const goToProject = useCallback((next) => {
    if (!projectCount) return

    setSelectedProject((current) => {
      const proposed = typeof next === 'function' ? next(current) : next

      if (typeof proposed !== 'number' || Number.isNaN(proposed)) {
        return current
      }

      const nextIndex = ((proposed % projectCount) + projectCount) % projectCount

      if (nextIndex === current) {
        return current
      }

      setPreviousProject(current)

      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current)
      }

      transitionTimeoutRef.current = setTimeout(() => {
        setPreviousProject(null)
        transitionTimeoutRef.current = null
      }, 1100)

      return nextIndex
    })
  }, [projectCount])

  // Auto-rotate through projects every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      goToProject((current) => (current + 1) % projectCount)
    }, 4000)

    return () => clearInterval(interval)
  }, [goToProject, projectCount])

  useEffect(() => {
    return () => {
      if (transitionTimeoutRef.current) {
        clearTimeout(transitionTimeoutRef.current)
      }
    }
  }, [])

  // Listen for menu toggle from Header component
  useEffect(() => {
    const handleMenuToggle = (event) => {
      setIsMobileMenuOpen(event.detail.isOpen)
    }

    window.addEventListener('headerMenuToggle', handleMenuToggle)
    return () => window.removeEventListener('headerMenuToggle', handleMenuToggle)
  }, [])

  return (
    <section className="hero-three">
      <div className="hero-background">
        {previousProject !== null && previousProject !== selectedProject && (
          <div
            key={`prev-${projects[previousProject].name}`}
            className="hero-bg-layer hero-bg-previous"
            style={{ backgroundImage: `url(${projects[previousProject].bgImage})` }}
          ></div>
        )}
        <div 
          className="hero-bg-layer hero-bg-active" 
          key={`active-${projects[selectedProject].name}`}
          style={{ backgroundImage: `url(${projects[selectedProject].bgImage})` }}
        ></div>
        <div className="hero-overlay"></div>
      </div>
      
      {/* Mobile Project List - Top right on mobile */}
      <div className="hero-mobile-projects">
        <div className="project-selector">
          {projects.map((project, index) => (
            <div 
              key={project.name}
              className={`project-item ${selectedProject === index ? 'active' : ''}`}
              onClick={() => goToProject(index)}
            >
              <span className="project-name">{project.name}</span>
              <div className="project-indicator">
                <div className={`indicator-dot ${selectedProject === index ? 'active' : ''}`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="hero-container">
      </div>

      <div className="hero-content-bottom">
        <h1 className="hero-title">Experience Excellence with Vulturelines </h1>
        <p className="hero-description">
        With strategic design and Webflow development.
        </p>
      </div>

      <div className="hero-sidebar">
        <div className="project-selector">
          {projects.map((project, index) => (
            <div 
              key={project.name}
              className={`project-item ${selectedProject === index ? 'active' : ''}`}
              onClick={() => goToProject(index)}
            >
              <span className="project-name">{project.name}</span>
              <div className="project-indicator">
                <div className={`indicator-dot ${selectedProject === index ? 'active' : ''}`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="hero-actions">
        <button 
          className="btn btn-outline"
          onClick={(e) => handleNavigationClick(e, '/work')}
        >
          All Projects
        </button>
        <button 
          className="btn btn-outline-white"
          onClick={(e) => handleNavigationClick(e, '/our-service')}
        >
          Our Services
        </button>
      </div>
    </section>
  )
}

export default HeroThree
